--[[
  ios_jump_unstick.lua
  OpenMW 0.51 player script

  The first version called I.Controls.overrideMovementControls(true) so we
  could pulse Jump. That also disabled the built-in walk/strafe/sneak
  handler, which is why the left stick stopped moving the player.

  This revision still owns movement (required to control Jump) but forwards
  forward/back/strafe/run/sneak from the same input actions the stock
  playercontrols.lua uses, including the analog left stick.
]]

local input = require('openmw.input')
local self = require('openmw.self')
local I = require('openmw.interfaces')
local types = require('openmw.types')

I.Controls.overrideMovementControls(true)

local prevJump = false
local pulse = 0

local function actionBool(name)
    local ok, v = pcall(input.getBooleanActionValue, name)
    return ok and v and true or false
end

local function actionRange(name)
    local ok, v = pcall(input.getRangeActionValue, name)
    if ok and type(v) == 'number' then
        return v
    end
    return 0
end

local function jumpHeld()
    if actionBool('Jump') then
        return true
    end
    if input.isActionPressed and input.ACTION and input.ACTION.Jump then
        local ok, v = pcall(input.isActionPressed, input.ACTION.Jump)
        if ok and v then
            return true
        end
    end
    return false
end

local function jumpingAllowed()
    local Player = types.Player
    if Player and Player.getControlSwitch and Player.CONTROL_SWITCH then
        local ok, on = pcall(Player.getControlSwitch, self, Player.CONTROL_SWITCH.Jumping)
        if ok then
            return on
        end
    end
    return true
end

local function requestHop()
    if jumpingAllowed() then
        pulse = 2
    end
end

local function processMovement()
    local movement = actionRange('MoveForward') - actionRange('MoveBackward')
    local sideMovement = actionRange('MoveRight') - actionRange('MoveLeft')

    -- Analog fallback if the range actions stay at 0
    if math.abs(movement) < 0.01 then
        local fb = actionRange('MoveForwardBackward')
        if fb ~= 0 and math.abs(fb - 0.5) > 0.08 then
            -- ICS rest is 0.5; forward is typically below 0.5
            movement = (0.5 - fb) * 2
        end
    end
    if math.abs(sideMovement) < 0.01 then
        local lr = actionRange('MoveLeftRight')
        if lr ~= 0 and math.abs(lr - 0.5) > 0.08 then
            sideMovement = (lr - 0.5) * 2
        end
    end

    local runHeld = actionBool('Run')
    local alwaysRun = false
    pcall(function()
        local storage = require('openmw.storage')
        local section = storage.playerSection('OMWControls')
        if not section then
            section = storage.playerSection('SettingsOMWControls')
        end
        if section and section.get then
            alwaysRun = section:get('alwaysRun') and true or false
        end
    end)

    self.controls.movement = movement
    self.controls.sideMovement = sideMovement
    self.controls.run = runHeld ~= alwaysRun
    self.controls.sneak = actionBool('Sneak')
end

return {
    engineHandlers = {
        onFrame = function(dt)
            processMovement()

            local held = jumpHeld()
            if held and not prevJump then
                requestHop()
            end
            prevJump = held

            if pulse > 0 then
                self.controls.jump = true
                pulse = pulse - 1
            else
                self.controls.jump = false
            end
        end,

        onTouchPress = function(e)
            -- Stuck Jump binding cannot produce another rising edge.
            -- A new finger-down is the player's intent to hop again.
            if prevJump then
                requestHop()
            end
        end,
    },
}
